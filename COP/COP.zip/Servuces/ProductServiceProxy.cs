﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using COP.Models;

namespace COP.Servuces
{
    public class ProductServiceProxy
    {

        private static ProductServiceProxy? instance;
        private static object instanceLock = new object();

        private ProductServiceProxy()
        {
            Products = new List<Product?>();
            Cart = new List<Product?>();
        }
        public static ProductServiceProxy? Current
        {
            get
            {
                lock (instanceLock)
                {

                    if (instance == null)
                    {
                        instance = new ProductServiceProxy();
                    }
                }
                return instance;
            }
        }


        public List<Product?> Products { get; private set; }
        public List<Product?> Cart { get; private set; }



        public Product AddOrUpdate(Product product)
        {
            var existing = Products.FirstOrDefault(p => p.Id == product.Id);
            if (existing == null)
            {
                product.Id = Products.Count + 1;
                Products.Add(product);
            }
            else
            {
                existing.Name = product.Name;
                existing.Price = product.Price;
                existing.StockQuantity = product.StockQuantity;
            }

            return product;

        }

        public void DisplayInventory()
        {
            Console.WriteLine("Inventory: ");
            Products.ForEach(Console.WriteLine);
        }

        public void Update(int id, string newName, decimal newPrice, int newStock)
        {
            var product = Products.FirstOrDefault(p => p.Id == id);
            if (product != null)
            {
                product.Name = newName;
                product.Price = newPrice;
                product.StockQuantity = newStock;
                Console.WriteLine("Item Updated.");


            }
            else
            {
                Console.WriteLine("Product not found.");
            }
        }

        public Product? Delete(int id)
        {
            var product = Products.FirstOrDefault(p => p.Id == id);
            if (product != null)
            {
                Products.Remove(product);
            }
            return product;
        }

        public void AddToCart(int id, int quantity)
        {
            var product = Products.FirstOrDefault(p => p.Id == id);
            if (product != null && product.StockQuantity >= quantity)
            {
                product.StockQuantity -= quantity;
                var cartProduct = new Product(product.Name, product.Price, product.StockQuantity)
                {
                    Id = product.Id,
                    CartQuantity = quantity
                };
                Cart.Add(cartProduct);
            }
            else
            {
                Console.WriteLine("Product is not stocked enough.");
            }
        }
    
        public void DisplayCart()
        {
            Console.WriteLine("Shopping Cart:");
            Cart.ForEach(item => Console.WriteLine(item?.CartDisplay));
        }


        public void UpdateCart(int id, int newQuantity) {
            var item = Cart.FirstOrDefault(p => p.Id == id);
            if (item != null)
            {
                var inventoryItem = Products.FirstOrDefault(p => p.Name == item.Name);
                if (inventoryItem != null && inventoryItem.StockQuantity + item.CartQuantity >= newQuantity)
                {
                    int quantityChange = newQuantity - item.CartQuantity;
                    inventoryItem.StockQuantity -= quantityChange;
                    item.CartQuantity = newQuantity;
                    Console.WriteLine("Cart item successfully updated");
                }
                else
                {
                    Console.WriteLine("Insufficient stock");
                }

            }
            else
            {
                Console.WriteLine("Cart item not found.");
            }
        }
        public void DeleteFromCart(int id)
        {
            var item = Cart.FirstOrDefault(p => p.Id == id);
            if (item != null)
            {
                Cart.Remove(item);
                var product = Products.FirstOrDefault(p => p.Name == item.Name);
                if (product != null)
                {
                    product.StockQuantity += item.CartQuantity;
                }
            }
        }

        public void Checkout()
        {
            decimal total = Cart.Sum(p => p.Price * p.CartQuantity);
            decimal tax = total * 0.07m;
            decimal finalTotal = total + tax;

            Console.WriteLine("Reciept: ");
            Cart.ForEach(item => Console.WriteLine(item.CartDisplay));
            Console.WriteLine($"Subtotal: ${total:F2}");
            Console.WriteLine($"Tax: ${tax:F2}");
            Console.WriteLine($"Total: ${finalTotal:F2}");

            Cart.Clear();
        }

    }
}
